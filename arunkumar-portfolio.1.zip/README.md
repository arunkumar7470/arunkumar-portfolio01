# Arunkumar Portfolio Website

This is my personal portfolio showcasing my data analyst projects and skills.

🌐 **Live Demo**: https://yourusername.github.io/arunkumar-portfolio

## 💼 About Me
I'm a data analyst skilled in:
- Python
- SQL
- Power BI
- Excel

## 📊 Projects
- Power BI Sales Dashboard
- SQL-based Customer Segmentation
- Python Data Cleaning Script

## 📫 Contact
Email: arunoffice001@gmail.com
